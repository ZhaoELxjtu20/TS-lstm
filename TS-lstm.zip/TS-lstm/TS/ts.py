# -*- coding: utf-8 -*-
"""

@author: TS-lstm
"""

from sklearn import preprocessing
import heapq
import pandas as pd
import heapq
import numpy as np
####DTW
from scipy.spatial.distance import cdist
from math import isinf
from numpy import array, zeros, full, argmin, inf, ndim
from sklearn.metrics.pairwise import manhattan_distances

def _traceback(D):
    i, j = array(D.shape) - 2
    p, q = [i], [j]
    while (i > 0) or (j > 0):
        tb = argmin((D[i, j], D[i, j + 1], D[i + 1, j]))
        if tb == 0:
            i -= 1
            j -= 1
        elif tb == 1:
            i -= 1
        else:  # (tb == 2):
            j -= 1
        p.insert(0, i)
        q.insert(0, j)
    return array(p), array(q)
def dtw(x, y, dist, warp=1, w=np.inf, s=1.0):
    assert len(x)
    assert len(y)
    assert isinf(w) or (w >= abs(len(x) - len(y)))
    assert s > 0
    r, c = len(x), len(y)
    if not isinf(w):
        D0 = full((r + 1, c + 1), inf)
        for i in range(1, r + 1):
            D0[i, max(1, i - w):min(c + 1, i + w + 1)] = 0
        D0[0, 0] = 0
    else:
        D0 = zeros((r + 1, c + 1))
        D0[0, 1:] = inf
        D0[1:, 0] = inf
    D1 = D0[1:, 1:]  # view
    for i in range(r):
        for j in range(c):
            if (isinf(w) or (max(0, i - w) <= j <= min(c, i + w))):
                D1[i, j] = dist(x[i], y[j])
    C = D1.copy()
    jrange = range(c)
    for i in range(r):
        if not isinf(w):
            jrange = range(max(0, i - w), min(c, i + w + 1))
        for j in jrange:
            min_list = [D0[i, j]]
            for k in range(1, warp + 1):
                i_k = min(i + k, r)
                j_k = min(j + k, c)
                min_list += [D0[i_k, j] * s, D0[i, j_k] * s]
            D1[i, j] += min(min_list)
    if len(x) == 1:
        path = zeros(len(y)), range(len(y))
    elif len(y) == 1:
        path = range(len(x)), zeros(len(x))
    else:
        path = _traceback(D0)
    return D1[-1, -1], C, D1, path
    
 ####frechetdist
def _c(ca, i, j, p, q):
    if ca[i, j] > -1:
        return ca[i, j]
    elif i == 0 and j == 0:
        ca[i, j] = np.linalg.norm(p[i]-q[j])
    elif i > 0 and j == 0:
        ca[i, j] = max(_c(ca, i-1, 0, p, q), np.linalg.norm(p[i]-q[j]))
    elif i == 0 and j > 0:
        ca[i, j] = max(_c(ca, 0, j-1, p, q), np.linalg.norm(p[i]-q[j]))
    elif i > 0 and j > 0:
        ca[i, j] = max(min(_c(ca, i-1, j, p, q),_c(ca, i-1, j-1, p, q),_c(ca, i, j-1, p, q)),np.linalg.norm(p[i]-q[j]))
    else:
        ca[i, j] = float('inf')
    return ca[i, j]

def frdist(p, q):
    p = np.array(p, np.float64)
    q = np.array(q, np.float64)

    len_p = len(p)
    len_q = len(q)

    if len_p == 0 or len_q == 0:
        raise ValueError('Input curves are empty.')

    if len_p != len_q or len(p[0]) != len(q[0]):
        raise ValueError('Input curves do not have the same dimensions.')

    ca = (np.ones((len_p, len_q), dtype=np.float64) * -1)

    dist = _c(ca, len_p-1, len_q-1, p, q)
    return dist   

def get_ori(path):
    df = pd.DataFrame(pd.read_excel(path))
    day_time = [str(i).split(" ")[0] for i in df['time']]
    pice = list(df['pice'])
    return day_time,pice

def cut_data(a,wind=10):
    x = []
    y = []
    for i in range(len(a)-wind+1):#dyn_wind是可以更改的动态周期
        te = a[i:i+wind]
        te2 = a[i+wind-1]
        x.append(te)
        y.append(te2)
    return x,y    

def confrdist(las,tes):     
    tem_las = np.array(las).reshape(-1,1)
    tem_i = np.array(tes).reshape(-1,1)
    dist = frdist(tem_las,tem_i)
    return dist


def cut_dou_data(A,wind=10):
    x = []
    for i in range(len(A)-wind):#dyn_wind是可以更改的动态周期
        te = A[i:i+wind]
        x.append(te)
    return x

def to_1(l):
    m1 = max(l)
    m2 = min(l)
    lo = m1-m2
    tem = [(i-m2)/lo for i in l]
    return tem

if __name__ == '__main__':
    path = './黄金期货结算价(日).xls'
    day_time,pice = get_ori(path)
    vol_day_time,vol = get_vol(vom_path)
    x1,y = cut_data(pice)
    x = [to_1(u) for u in x1]
    l_df = len(day_time)
    ind1 = day_time.index('2019-01-02')###2019-01-03对应的index
    ind2 = day_time.index('2020-09-07')##2020-09-07对应的index
    ind3 = day_time.index('2020-09-25')##20120-09-25对应的index
    print("匹配字典，训练，测试需要的下标：",ind1,ind2,ind3)
    bais_dict = x[:ind2-9]###将要匹配的数据的集合，即从20080109到20181231之间的数据作为匹配的历史数据
    train_df = x[ind1-9:ind3-9]#训练的集合这一部分得到对应历史的预测值 存起来备用
    test_df = x[-10-9:]###要预测的数据集合 检测预测的效果的数据集合
    print("数据长度：原始长度，划分后的长度",len(day_time),len(bais_dict),len(train_df),len(test_df))

    w = inf
    s = 1.0
    dist_fun = manhattan_distances
  
    ###DTW
    y_all = []
    out_num = 0
    bais_dict = bais_dict
    ned_y_ind = []
    for train_df_i in range(len(train_df)):
#        print(train_df[train_df_i])
        print("****共有",len(train_df),"待处理",423-train_df_i,"*****")
        now_len = 423-train_df_i
        bais_di = bais_dict[:-now_len]
        dists = [dtw(train_df[train_df_i],da, dist_fun, w=w, s=s)[0] for da in bais_di]##dtwt距离
#        dists = [confrdist(train_df[train_df_i],da) for da in bais_di]####fis距离
        ind_res_all = list(zip(map(dists.index,heapq.nsmallest(20,dists)),heapq.nsmallest(20,dists)))
        ind_res = [i[0] for i in ind_res_all]
        ned_y_ind.append(ind_res)

